clear all;clc; %运动伪迹去除代码
DataMatrix = readmatrix('data_12.csv');
R = 4;
M = 200;
Fs = 1024;
EMG_Reconstruct = MotionArtifactRemoval( DataMatrix,Fs);

